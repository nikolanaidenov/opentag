package export;

import java.util.List;


import apartment.ApartmentData;

public class SaveToFile {
	public static void writeToFile(List<ApartmentData> apartmentsList) throws Exception {
		//TO DO
	}
	
}

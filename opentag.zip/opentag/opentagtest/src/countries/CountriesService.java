package countries;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;



public class CountriesService {
	
	private static String URLLINK = "https://restcountries.eu/rest/v2/all?fields=name;capital;currencies";
	//private static String PATH = "/rest/v2/all";
	//fields=name;capital;currencies
	
	public List<CountriesData> getCountriesList() throws Exception{
		
		URL url = new URL(URLLINK);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
			
		BufferedReader buffer = new BufferedReader(
				  new InputStreamReader(connection.getInputStream()));
		
		String inputStr;
		StringBuffer response = new StringBuffer();
		
		while ((inputStr = buffer.readLine()) != null) {
			response.append(inputStr);
		}		
		
		String values = response.toString();
		
		List<CountriesData> coutriesData = null;
		ObjectMapper objectMapper = new ObjectMapper();
		coutriesData = objectMapper.readValue(values, new TypeReference<List<CountriesData>>(){}); 

		return coutriesData;
	}

}

package countries;

import java.util.List;

import apartment.ApartmentData;
import apartment.GenerateApartmentData;
import export.SaveToFile;

public class OpenTagAssignment {
	public static void main(String args[]) {
		try {
			//Call countries service
			CountriesService countries = new CountriesService();
			List<CountriesData> coutriesList = countries.getCountriesList();
			
			//Generate apartment data based on countries list
			List<ApartmentData> apartmentsList= GenerateApartmentData.generateAppartmentData(coutriesList);
			
			//Save the output data to a file.
			SaveToFile.writeToFile(apartmentsList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

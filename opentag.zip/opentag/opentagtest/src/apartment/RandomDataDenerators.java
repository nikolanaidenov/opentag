package apartment;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Random;

public class RandomDataDenerators {
	
	public static String randomNameGenerator() {
		int leftLimit = 97;
	    int rightLimit = 122;
	    int targetStringLength = 10;
	    Random random = new Random();

	    String generatedString = random.ints(leftLimit, rightLimit + 1)
	    	      .limit(targetStringLength)
	    	      .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
	    	      .toString();
	    
	    return generatedString;
	}

	public static int randomIntGenerator(int min, int max) {
		return min + (int)Math.round(Math.random() * (max - min));
	}
	
	public static String getAptType() {
		String[] aptTypes = {"Sale","Rental","Both"}; 
		int type = randomIntGenerator(0,2);
		return aptTypes[type];
	}

}

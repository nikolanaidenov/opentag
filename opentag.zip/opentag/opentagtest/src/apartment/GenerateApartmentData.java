package apartment;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import countries.CountriesData;

public class GenerateApartmentData {
	
	public static List<ApartmentData> generateAppartmentData(List<CountriesData> coutriesList) {
		List<ApartmentData> apartmentsList = new ArrayList<ApartmentData>();
		ApartmentData data = new ApartmentData();
		
		//coutriesList.size() is replaces by 4 to reduce the generated data
		for (int i = 0; i < 4; i++) {
			data.setApartmentName(RandomDataDenerators.randomNameGenerator());
			data.setCountry(coutriesList.get(i).getName());
			data.setPrice(RandomDataDenerators.randomIntGenerator(10000,500000));
			data.setCurrency(coutriesList.get(i).getCurrencies().get(0).getName());
			data.setCurrencySymbol(coutriesList.get(i).getCurrencies().get(0).getSymbol());
			data.setApartmentAddress(RandomDataDenerators.randomNameGenerator() + " " + RandomDataDenerators.randomIntGenerator(1,30));
			data.setApartmentSize(RandomDataDenerators.randomIntGenerator(0,500));
			data.setApartmentType(RandomDataDenerators.getAptType());
			Date d=new Date();
			data.setConstructionDate(RandomDataDenerators.randomIntGenerator(1980,Calendar.getInstance().get(Calendar.YEAR)));	
			
			apartmentsList.add(i, data);
        }

		return apartmentsList;
	}

}

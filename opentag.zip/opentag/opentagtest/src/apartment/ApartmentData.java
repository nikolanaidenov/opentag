package apartment;

public class ApartmentData {

	private String apartmentName;
	private String country;
	private int price;
	private String currency;
	private String currencySymbol;
	private String apartmentAddress;
	private int apartmentSize;
	private String apartmentType;
	private int constructionDate;
	
	public String getApartmentName() {
		return apartmentName;
	}
	
	public void setApartmentName(String apartmentName) {
		this.apartmentName = apartmentName;
	}
	
	public String getApartmentAddress() {
		return apartmentAddress;
	}
	
	public void setApartmentAddress(String apartmentAddress) {
		this.apartmentAddress = apartmentAddress;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCurrencySymbol() {
		return currencySymbol;
	}

	public void setCurrencySymbol(String currencySymbol) {
		this.currencySymbol = currencySymbol;
	}

	public int getApartmentSize() {
		return apartmentSize;
	}

	public void setApartmentSize(int apartmentSize) {
		this.apartmentSize = apartmentSize;
	}

	public String getApartmentType() {
		return apartmentType;
	}

	public void setApartmentType(String apartmentType) {
		this.apartmentType = apartmentType;
	}

	public int getConstructionDate() {
		return constructionDate;
	}

	public void setConstructionDate(int constructionDate) {
		this.constructionDate = constructionDate;
	}
	
}

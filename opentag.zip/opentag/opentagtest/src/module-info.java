module opentag {
	requires com.fasterxml.jackson.databind;
	requires com.fasterxml.jackson.core;
	requires jackson.annotations;
	
	 exports countries;
}